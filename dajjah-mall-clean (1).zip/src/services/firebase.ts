import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth,
  initializeAuth,
  indexedDBLocalPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  browserPopupRedirectResolver,
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  deleteUser,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  EmailAuthProvider,
  signOut, 
  onAuthStateChanged,
  updateProfile,
  Auth,
  PopupRedirectResolver,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  memoryLocalCache,
  setLogLevel,
  collection, 
  doc, 
  getDoc, 
  getDocFromServer,
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  limit,
  onSnapshot,
  Unsubscribe,
  writeBatch,
  runTransaction
} from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import fbSettings from '../config/firebase.config.json';
import { OWNER_EMAIL } from '../config/owner';
import { Product, Order, Address, UserProfile, CartItem, ExchangeRates, Category, Store, Brand, AppSettings, FooterConfig, ReviewItem, Coupon } from '../types';
import { PRODUCTS, CATEGORIES, STORES, DEFAULT_FOOTER_CONFIG } from '../data/mockData';
import { DEFAULT_EXCHANGE_RATES, getRegionFromCity } from './currencyService';

export const firebaseConfig = {
  apiKey: fbSettings.apiKey,
  authDomain: fbSettings.authDomain,
  projectId: fbSettings.projectId,
  storageBucket: fbSettings.storageBucket,
  messagingSenderId: fbSettings.messagingSenderId,
  appId: fbSettings.appId,
  firestoreDatabaseId: fbSettings.firestoreDatabaseId || "(default)",
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

let SafePopupResolver: PopupRedirectResolver = browserPopupRedirectResolver;
if (typeof browserPopupRedirectResolver === 'function') {
  try {
    class GuardedBrowserPopupRedirectResolver extends (browserPopupRedirectResolver as unknown as new () => any) {
      async _initialize(authInstance: any) {
        const manager = await super._initialize(authInstance);
        if (manager && typeof manager.registerConsumer === 'function' && !manager.__dajjahPatched) {
          const origRegisterConsumer = manager.registerConsumer.bind(manager);
          manager.registerConsumer = (consumer: any) => {
            if (!consumer || !consumer.pendingPromise) {
              return;
            }
            if (!consumer.__dajjahGuarded) {
              consumer.__dajjahGuarded = true;
              if (typeof consumer.resolve === 'function') {
                const origResolve = consumer.resolve.bind(consumer);
                consumer.resolve = (cred: any) => {
                  if (!consumer.pendingPromise) return;
                  return origResolve(cred);
                };
              }
              if (typeof consumer.reject === 'function') {
                const origReject = consumer.reject.bind(consumer);
                consumer.reject = (err: any) => {
                  if (!consumer.pendingPromise) return;
                  return origReject(err);
                };
              }
              if (typeof consumer.onAuthEvent === 'function') {
                const origOnAuthEvent = consumer.onAuthEvent.bind(consumer);
                consumer.onAuthEvent = async (event: any) => {
                  if (!consumer.pendingPromise) return;
                  try {
                    await origOnAuthEvent(event);
                  } catch (err: any) {
                    const msg = String(err?.message || err || '');
                    if (msg.includes('Pending promise was never set')) {
                      return;
                    }
                    if (consumer.pendingPromise && typeof consumer.reject === 'function') {
                      consumer.reject(err);
                    }
                  }
                };
              }
            }
            return origRegisterConsumer(consumer);
          };
          manager.__dajjahPatched = true;
        }
        return manager;
      }
    }
    SafePopupResolver = GuardedBrowserPopupRedirectResolver as unknown as PopupRedirectResolver;
  } catch {
    SafePopupResolver = browserPopupRedirectResolver;
  }
}

let authInstance: Auth;
try {
  authInstance = initializeAuth(app, {
    persistence: [
      indexedDBLocalPersistence,
      browserLocalPersistence,
      browserSessionPersistence,
    ],
    popupRedirectResolver: SafePopupResolver,
  });
} catch {
  authInstance = getAuth(app);
}
export const auth = authInstance;

try {
  setLogLevel('silent');
} catch {}

let firestoreInstance;
try {
  firestoreInstance = initializeFirestore(
    app,
    {
      localCache: persistentLocalCache({
        tabManager: persistentMultipleTabManager(),
      }),
    },
    firebaseConfig.firestoreDatabaseId
  );
} catch {
  try {
    firestoreInstance = initializeFirestore(
      app,
      {
        localCache: memoryLocalCache(),
      },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    firestoreInstance = getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
}

export const db = firestoreInstance;
export const storage = getStorage(app);

export async function withFirestoreTimeout<T>(promise: Promise<T>, timeoutMs = 2500, fallbackValue: T): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<T>((resolve) => {
    timer = setTimeout(() => resolve(fallbackValue), timeoutMs);
  });
  try {
    const result = await Promise.race([promise, timeoutPromise]);
    clearTimeout(timer);
    return result;
  } catch {
    clearTimeout(timer);
    return fallbackValue;
  }
}

export async function testFirebaseConnection(): Promise<{ connected: boolean; mode: 'online' | 'offline'; error?: string }> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return { connected: true, mode: 'online' };
  } catch (err: any) {
    if (isOfflineError(err)) {
      return { connected: true, mode: 'offline' };
    }
    return { connected: false, mode: 'offline', error: err?.message || String(err) };
  }
}

export const isFirebaseConfigured = Boolean(firebaseConfig.projectId && firebaseConfig.apiKey);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function isOfflineError(error: unknown): boolean {
  if (!error) return false;
  const msg = error instanceof Error ? error.message.toLowerCase() : String(error).toLowerCase();
  const code = (error as any)?.code || '';
  return (
    msg.includes('offline') ||
    msg.includes('network-request-failed') ||
    msg.includes('backend didn\'t respond') ||
    msg.includes('could not reach cloud firestore') ||
    msg.includes('unavailable') ||
    msg.includes('closing') ||
    msg.includes('hidden') ||
    msg.includes('database is closing') ||
    msg.includes('database is closing/hidden') ||
    msg.includes('indexeddb') ||
    msg.includes('abort') ||
    code === 'unavailable' ||
    code === 'auth/network-request-failed' ||
    code === 'failed-precondition' ||
    code === 'cancelled'
  );
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  if (isOfflineError(error)) {
    return;
  }
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Operation Info:', JSON.stringify(errInfo));
}
export function sanitizeForFirestore<T>(data: T): T {
  if (data === undefined) {
    return null as unknown as T;
  }
  if (data === null || typeof data !== 'object') {
    return data;
  }
  if (data instanceof Date) {
    return data.toISOString() as unknown as T;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as unknown as T;
  }
  const result: Record<string, any> = {};
  for (const [key, value] of Object.entries(data as Record<string, any>)) {
    if (value !== undefined) {
      result[key] = sanitizeForFirestore(value);
    }
  }
  return result as T;
}

export function translateAuthError(error: any): string {
  if (!error) return 'حدث خطأ غير متوقع أثناء عملية المصادقة. يرجى المحاولة مرة أخرى.';

  const code = (error?.code || '').toLowerCase();
  const rawMsg = error instanceof Error ? error.message : String(error?.message || error || '');
  const msg = rawMsg.toLowerCase();

  if (
    code === 'auth/user-not-found' || 
    code === 'auth/wrong-password' || 
    code === 'auth/invalid-credential' || 
    code === 'auth/invalid-login-credentials' ||
    msg.includes('invalid-credential') ||
    msg.includes('invalid-login-credentials') ||
    msg.includes('wrong-password') ||
    msg.includes('user-not-found')
  ) {
    return 'بيانات الدخول غير صحيحة. يرجى التأكد من البريد الإلكتروني وكلمة المرور أو إنشاء حساب جديد.';
  }

  if (code === 'auth/email-already-in-use' || msg.includes('email-already-in-use')) {
    return 'هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول أو النقر على "نسيت كلمة المرور".';
  }

  if (code === 'auth/weak-password' || msg.includes('weak-password')) {
    return 'كلمة المرور ضعيفة. يجب أن تتكون من 6 خانات أو أكثر لحماية حسابك.';
  }

  if (code === 'auth/invalid-email' || msg.includes('invalid-email')) {
    return 'صيغة البريد الإلكتروني غير صحيحة. يرجى كتابة بريد صالح مثل example@gmail.com.';
  }

  if (code === 'auth/missing-email' || msg.includes('missing-email')) {
    return 'يرجى إدخال البريد الإلكتروني للمتابعة.';
  }
  if (code === 'auth/missing-password' || msg.includes('missing-password')) {
    return 'يرجى إدخال كلمة المرور.';
  }

  if (
    code === 'auth/popup-closed-by-user' || 
    code === 'auth/cancelled-popup-request' ||
    msg.includes('popup-closed-by-user') ||
    msg.includes('cancelled-popup-request')
  ) {
    return 'تم إغلاق نافذة تسجيل الدخول قبل إكمال العملية.';
  }

  if (
    msg.includes('internal assertion failed') ||
    msg.includes('pending promise was never set') ||
    code === 'auth/internal-error'
  ) {
    return 'حدث تعارض أثناء فتح نافذة تسجيل الدخول. يرجى المحاولة مرة أخرى أو استخدام تسجيل الدخول بالبريد الإلكتروني.';
  }

  if (code === 'auth/popup-blocked' || msg.includes('popup-blocked')) {
    return 'تم حظر النافذة المنبثقة من قبل المتصفح أو WebView. يرجى السماح بالنوافذ أو تسجيل الدخول بالبريد الإلكتروني مباشرة.';
  }

  if (code === 'auth/disallowed-useragent' || msg.includes('disallowed_useragent') || msg.includes('disallowed-useragent')) {
    return 'تسجيل الدخول عبر Google غير مدعوم في متصفح WebView الداخلي. يرجى تسجيل الدخول بالبريد الإلكتروني وكلمة المرور فوراً.';
  }

  if (code === 'auth/web-storage-unsupported' || msg.includes('web-storage-unsupported')) {
    return 'المتصفح الحالي يقيّد مساحة التخزين للنوافذ المنبثقة. يرجى فتح التطبيق في نافذة مستقلة أو تسجيل الدخول بالبريد الإلكتروني وكلمة المرور.';
  }

  if (code === 'auth/account-exists-with-different-credential' || msg.includes('account-exists-with-different-credential')) {
    return 'يوجد حساب مسجل بالفعل بهذا البريد عبر مزود خدمة آخر. يرجى تسجيل الدخول بالبريد وكلمة المرور.';
  }

  if (code === 'auth/network-request-failed' || msg.includes('network-request-failed') || msg.includes('failed to fetch')) {
    return 'تعذر الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت ثم إعادة المحاولة.';
  }

  if (code === 'auth/too-many-requests' || msg.includes('too-many-requests')) {
    return 'تم حظر المحاولات مؤقتاً بسبب كثرة المحاولات. يرجى الانتظار دقيقة واحدة ثم المحاولة مجدداً.';
  }

  if (code === 'auth/user-disabled' || msg.includes('user-disabled')) {
    return 'تم تعطيل هذا الحساب. يرجى التواصل مع خدمة عملاء ضَجّة مول.';
  }

  if (code === 'auth/operation-not-allowed' || msg.includes('operation-not-allowed')) {
    return 'طريقة تسجيل الدخول هذه غير مفعلة حالياً في خادم Firebase. يمكنك المتابعة بحساب Google أو البريد الإلكتروني فوراً.';
  }

  if (code === 'auth/timeout' || msg.includes('timeout') || msg.includes('مهلة')) {
    return 'استغرقت عملية تسجيل الدخول وقتاً أطول من المتوقع. يرجى التأكد من اتصال الإنترنت ثم المحاولة مجدداً.';
  }

  if (code === 'auth/unauthorized-domain' || msg.includes('unauthorized-domain')) {
    return 'نطاق التطبيق الحالي غير مضاف في قائمة النطاقات المصرح بها في إعدادات Firebase Auth.';
  }

  if (rawMsg.startsWith('Firebase:') || rawMsg.includes('auth/')) {
    return 'حدث خطأ أثناء عملية المصادقة. يرجى التحقق من صحة البيانات والمحاولة مرة أخرى.';
  }

  return rawMsg || 'حدث خطأ أثناء عملية المصادقة. يرجى التأكد من البيانات والمحاولة مرة أخرى.';
}

let activeGoogleLoginPromise: Promise<UserProfile> | null = null;

export const firebaseAuthService = {
  async registerWithEmail(email: string, pass: string, name: string, phone: string, city: string): Promise<UserProfile> {
    if (typeof auth.authStateReady === 'function') {
      await auth.authStateReady();
    }
    const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
    const firebaseUser = userCredential.user;

    try {
      await updateProfile(firebaseUser, { displayName: name });
    } catch {}

    const region = getRegionFromCity(city || 'صنعاء');
    const isEmailAdmin = (email?.toLowerCase().trim() === OWNER_EMAIL);
    const userProfile: UserProfile = {
      id: firebaseUser.uid,
      name: name || 'مستخدم ضَجّة مول',
      phone: phone || '',
      email: email,
      city: city || 'صنعاء',
      preferredRegion: region,
      preferredCurrency: region === 'south' ? 'YER_SOUTH' : 'YER_NORTH',
      walletBalanceYER: 10000,
      points: 200,
      memberTier: isEmailAdmin ? 'مالك التطبيق — Admin' : 'عضو فضي',
      role: isEmailAdmin ? 'admin' : 'customer',
      savedAddresses: [
        {
          id: `addr-${Date.now()}`,
          userId: firebaseUser.uid,
          title: 'المنزل',
          recipientName: name || 'مستخدم ضَجّة مول',
          phone: phone || '',
          city: city || 'صنعاء',
          district: 'وسط المدينة',
          street: 'الشارع العام',
          region: region,
          isDefault: true,
        }
      ],
      favoriteProductIds: [],
      createdAt: new Date().toISOString(),
    };

    try {
      await withFirestoreTimeout(
        setDoc(doc(db, 'users', firebaseUser.uid), sanitizeForFirestore(userProfile)),
        3000,
        null
      );
    } catch {}

    return userProfile;
  },

  async loginWithEmail(email: string, pass: string): Promise<UserProfile> {
    if (typeof auth.authStateReady === 'function') {
      await auth.authStateReady();
    }
    const userCredential = await signInWithEmailAndPassword(auth, email, pass);
    const firebaseUser = userCredential.user;

    const userDocRef = doc(db, 'users', firebaseUser.uid);
    let snap: any = null;
    try {
      snap = await withFirestoreTimeout(getDoc(userDocRef), 3000, null);
    } catch {}

    const isEmailAdmin = (firebaseUser.email?.toLowerCase().trim() === OWNER_EMAIL);

    if (snap && snap.exists()) {
      const data = snap.data() as UserProfile;
      if (isEmailAdmin && data.role !== 'admin') {
        data.role = 'admin';
        data.memberTier = 'مالك التطبيق — Admin';
        try {
          await withFirestoreTimeout(
            updateDoc(userDocRef, { role: 'admin', memberTier: 'مالك التطبيق — Admin' }),
            2000,
            null
          );
        } catch {}
      }
      return data;
    } else {
      const region = getRegionFromCity('صنعاء');
      const newProfile: UserProfile = {
        id: firebaseUser.uid,
        name: firebaseUser.displayName || (isEmailAdmin ? 'ناصر العناتي (المالك)' : 'مستخدم ضَجّة مول'),
        phone: firebaseUser.phoneNumber || '',
        email: firebaseUser.email || email,
        city: 'صنعاء',
        preferredRegion: region,
        preferredCurrency: 'YER_NORTH',
        walletBalanceYER: 10000,
        points: 200,
        memberTier: isEmailAdmin ? 'مالك التطبيق — Admin' : 'عضو فضي',
        role: isEmailAdmin ? 'admin' : 'customer',
        savedAddresses: [],
        favoriteProductIds: [],
        createdAt: new Date().toISOString(),
      };
      try {
        await withFirestoreTimeout(
          setDoc(userDocRef, sanitizeForFirestore(newProfile)),
          3000,
          null
        );
      } catch {}
      return newProfile;
    }
  },

  async loginWithGoogle(): Promise<UserProfile> {
    if (activeGoogleLoginPromise) {
      return activeGoogleLoginPromise;
    }

    activeGoogleLoginPromise = (async () => {
      try {
        if (typeof auth.authStateReady === 'function') {
          await auth.authStateReady();
        }
        const provider = new GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });

        let result: any;
        try {
          result = await signInWithPopup(auth, provider, SafePopupResolver);
        } catch (popupError: any) {
          const code = popupError?.code || '';
          const msg = String(popupError?.message || '');

          if (
            code === 'auth/popup-closed-by-user' ||
            code === 'auth/cancelled-popup-request' ||
            msg.includes('popup-closed-by-user') ||
            msg.includes('cancelled-popup-request')
          ) {
            const err: any = new Error('تم إغلاق نافذة تسجيل الدخول قبل إكمال العملية.');
            err.code = 'auth/popup-closed-by-user';
            throw err;
          }

          if (
            msg.includes('INTERNAL ASSERTION FAILED') ||
            msg.includes('Pending promise was never set')
          ) {
            const err: any = new Error('حدث تعارض أثناء فتح نافذة تسجيل الدخول. يرجى المحاولة مرة أخرى أو استخدام تسجيل الدخول بالبريد الإلكتروني.');
            err.code = 'auth/internal-error';
            throw err;
          }

          if (code === 'auth/web-storage-unsupported' || msg.includes('web-storage-unsupported')) {
            const err: any = new Error('المتصفح الحالي يقيّد مساحة التخزين للنوافذ المنبثقة. يرجى استخدام تسجيل الدخول بالبريد الإلكتروني وكلمة المرور.');
            err.code = 'auth/web-storage-unsupported';
            throw err;
          }

          if (code === 'auth/popup-blocked' || msg.includes('popup-blocked')) {
            popupError.message = 'تم حظر النافذة المنبثقة من قبل المتصفح أو WebView. يرجى السماح بالنوافذ أو تسجيل الدخول بالبريد الإلكتروني مباشرة.';
          } else if (code === 'auth/disallowed-useragent' || msg.includes('disallowed-useragent')) {
            popupError.message = 'بيئة WebView الحالية تمنع نافذة Google المنبثقة. يرجى تسجيل الدخول بالبريد الإلكتروني وكلمة المرور.';
          }

          throw popupError;
        }

        const fbUser = result.user;
        const userDocRef = doc(db, 'users', fbUser.uid);
        let snap: any = null;
        try {
          snap = await withFirestoreTimeout(getDoc(userDocRef), 3000, null);
        } catch {}

        const isEmailAdmin = (fbUser.email?.toLowerCase().trim() === OWNER_EMAIL);

        if (snap && snap.exists()) {
          const existingData = snap.data() as UserProfile;
          const updated: Partial<UserProfile> = {
            avatarUrl: fbUser.photoURL || existingData.avatarUrl,
            email: fbUser.email || existingData.email,
            name: fbUser.displayName || existingData.name,
            role: isEmailAdmin ? 'admin' : existingData.role,
            memberTier: isEmailAdmin ? 'مالك التطبيق — Admin' : existingData.memberTier,
          };
          try {
            await withFirestoreTimeout(updateDoc(userDocRef, sanitizeForFirestore(updated)), 2000, null);
          } catch {}
          return { ...existingData, ...updated };
        } else {
          const region = getRegionFromCity('صنعاء');
          const newProfile: UserProfile = {
            id: fbUser.uid,
            name: fbUser.displayName || (isEmailAdmin ? 'ناصر العناتي (المالك)' : 'مستخدم Google'),
            phone: fbUser.phoneNumber || '',
            email: fbUser.email || '',
            avatarUrl: fbUser.photoURL || undefined,
            city: 'صنعاء',
            preferredRegion: region,
            preferredCurrency: 'YER_NORTH',
            walletBalanceYER: 10000,
            points: 200,
            memberTier: isEmailAdmin ? 'مالك التطبيق — Admin' : 'عضو فضي',
            role: isEmailAdmin ? 'admin' : 'customer',
            savedAddresses: [],
            favoriteProductIds: [],
            createdAt: new Date().toISOString(),
          };
          try {
            await withFirestoreTimeout(setDoc(userDocRef, sanitizeForFirestore(newProfile)), 3000, null);
          } catch {}
          return newProfile;
        }
      } finally {
        activeGoogleLoginPromise = null;
      }
    })();

    return activeGoogleLoginPromise;
  },

  async quickPhoneAuth(phone: string, name?: string, city?: string): Promise<UserProfile> {
    let firebaseUser: FirebaseUser | null = auth.currentUser;
    const cleanPhone = phone.startsWith('+967') ? phone : `+967 ${phone}`;
    const region = getRegionFromCity(city || 'صنعاء');
    const uid = firebaseUser?.uid || `user-${Date.now()}`;
    
    const userProfile: UserProfile = {
      id: uid,
      name: name || 'عميل ضَجّة مول',
      phone: cleanPhone,
      email: `${phone.replace(/\D/g, '')}@dajjahmall.ye`,
      city: city || 'صنعاء',
      preferredRegion: region,
      preferredCurrency: region === 'south' ? 'YER_SOUTH' : 'YER_NORTH',
      walletBalanceYER: 10000,
      points: 200,
      memberTier: 'عضو فضي',
      role: 'customer',
      savedAddresses: [],
      favoriteProductIds: [],
    };

    if (firebaseUser) {
      await setDoc(doc(db, 'users', firebaseUser.uid), sanitizeForFirestore(userProfile), { merge: true });
    }

    return userProfile;
  },

  async sendPasswordReset(email: string): Promise<void> {
    await sendPasswordResetEmail(auth, email);
  },

  async logout(): Promise<void> {
    await signOut(auth);
  },

  usesPasswordLogin(): boolean {
    return !!auth.currentUser?.providerData.some((p) => p.providerId === 'password');
  },

  async deleteAccount(password?: string): Promise<void> {
    const user = auth.currentUser;
    if (!user) throw new Error('not-signed-in');

    if (user.providerData.some((p) => p.providerId === 'password')) {
      if (!user.email || !password) throw new Error('password-required');
      await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password));
    } else {
      await reauthenticateWithPopup(user, new GoogleAuthProvider(), SafePopupResolver);
    }

    const uid = user.uid;
    for (const sub of ['addresses', 'notifications']) {
      const snap = await getDocs(collection(db, 'users', uid, sub));
      await Promise.all(snap.docs.map((d) => deleteDoc(d.ref)));
    }
    await Promise.all([
      deleteDoc(doc(db, 'carts', uid)).catch(() => undefined),
      deleteDoc(doc(db, 'favorites', uid)).catch(() => undefined),
    ]);
    await deleteDoc(doc(db, 'users', uid));
    await deleteUser(user);
  },

  onAuth(callback: (user: FirebaseUser | null) => void) {
    return onAuthStateChanged(auth, callback);
  }
};

export const firestoreCouponService = {
  docId(code: string): string {
    return code.toUpperCase().replace(/[^A-Z0-9_\-\u0600-\u06FF]/g, '_');
  },

  async getAll(): Promise<Coupon[] | null> {
    try {
      const snap = await withFirestoreTimeout(getDocs(collection(db, 'coupons')), 4000, null);
      if (!snap) return null;
      return snap.docs.map((d) => d.data() as Coupon);
    } catch {
      return null;
    }
  },

  async save(coupon: Coupon): Promise<void> {
    const code = coupon.code.toUpperCase();
    await setDoc(doc(db, 'coupons', this.docId(code)), sanitizeForFirestore({ ...coupon, code }));
  },

  async remove(code: string): Promise<void> {
    await deleteDoc(doc(db, 'coupons', this.docId(code)));
  },
};

export const firestoreReportService = {
  async reportReview(payload: { reviewId: string; productId: string; reason: string; userId?: string | null }): Promise<void> {
    const ref = doc(collection(db, 'reviewReports'));
    await setDoc(ref, {
      reviewId: String(payload.reviewId).slice(0, 200),
      productId: String(payload.productId).slice(0, 200),
      reason: payload.reason,
      userId: payload.userId || null,
      createdAt: new Date().toISOString(),
    });
  },

  async reportAiMessage(payload: {
    messageText: string;
    userMessage: string;
    reason: string;
    userId?: string | null;
  }): Promise<void> {
    const ref = doc(collection(db, 'aiReports'));
    await setDoc(ref, {
      messageText: payload.messageText.slice(0, 3500),
      userMessage: payload.userMessage.slice(0, 1000),
      reason: payload.reason,
      userId: payload.userId || null,
      createdAt: new Date().toISOString(),
    });
  },
};

export const firestoreCatalogService = {
  async getProducts(): Promise<Product[]> {
    try {
      const querySnapshot = await withFirestoreTimeout(
        getDocs(collection(db, 'products')),
        2500,
        null
      );
      if (querySnapshot && !querySnapshot.empty) {
        const list: Product[] = [];
        querySnapshot.forEach((d) => {
          list.push(d.data() as Product);
        });
        return list;
      }

      try {
        const batch = writeBatch(db);
        for (const prod of PRODUCTS) {
          const docRef = doc(db, 'products', prod.id);
          batch.set(docRef, {
            ...prod,
            createdAt: new Date().toISOString(),
          });
        }
        await batch.commit();
      } catch (seedErr) {
        if (!isOfflineError(seedErr)) {
          console.warn('Could not seed initial products to Firestore:', seedErr);
        }
      }
      return PRODUCTS;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching products from Firestore:', err);
      }
      return PRODUCTS;
    }
  },

  async getCategories(): Promise<Category[]> {
    try {
      const querySnapshot = await withFirestoreTimeout(
        getDocs(collection(db, 'categories')),
        2500,
        null
      );
      if (querySnapshot && !querySnapshot.empty) {
        const list: Category[] = [];
        querySnapshot.forEach((d) => {
          list.push(d.data() as Category);
        });
        return list;
      }

      try {
        const batch = writeBatch(db);
        for (const cat of CATEGORIES) {
          const docRef = doc(db, 'categories', cat.id);
          batch.set(docRef, cat);
        }
        await batch.commit();
      } catch (seedErr) {
        if (!isOfflineError(seedErr)) {
          console.warn('Could not seed categories to Firestore:', seedErr);
        }
      }
      return CATEGORIES;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching categories from Firestore:', err);
      }
      return CATEGORIES;
    }
  },

  async getStores(): Promise<Store[]> {
    try {
      const querySnapshot = await withFirestoreTimeout(
        getDocs(collection(db, 'stores')),
        2500,
        null
      );
      if (querySnapshot && !querySnapshot.empty) {
        const list: Store[] = [];
        querySnapshot.forEach((d) => {
          list.push(d.data() as Store);
        });
        return list;
      }

      try {
        const batch = writeBatch(db);
        for (const s of STORES) {
          const docRef = doc(db, 'stores', s.id);
          batch.set(docRef, s);
        }
        await batch.commit();
      } catch (seedErr) {
        if (!isOfflineError(seedErr)) {
          console.warn('Could not seed stores to Firestore:', seedErr);
        }
      }
      return STORES;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching stores from Firestore:', err);
      }
      return STORES;
    }
  },

  async addProduct(product: Product): Promise<Product> {
    try {
      const docRef = doc(db, 'products', product.id);
      await setDoc(docRef, sanitizeForFirestore({
        ...product,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error adding product to Firestore:', err);
      }
    }
    return product;
  },

  async updateProduct(id: string, updates: Partial<Product>): Promise<void> {
    try {
      const docRef = doc(db, 'products', id);
      await updateDoc(docRef, sanitizeForFirestore({
        ...updates,
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error updating product in Firestore:', err);
      }
    }
  },

  async deleteProduct(id: string): Promise<void> {
    try {
      const docRef = doc(db, 'products', id);
      await deleteDoc(docRef);
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error deleting product from Firestore:', err);
      }
    }
  },

  async updateProductStock(id: string, stock: number): Promise<void> {
    try {
      const docRef = doc(db, 'products', id);
      await updateDoc(docRef, {
        stock,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error updating stock in Firestore:', err);
      }
    }
  },

  subscribeToProducts(callback: (products: Product[]) => void): Unsubscribe {
    try {
      const q = collection(db, 'products');
      return onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: Product[] = [];
          snapshot.forEach((d) => {
            list.push(d.data() as Product);
          });
          callback(list);
        }
      }, (error) => {
        if (!isOfflineError(error)) {
          console.warn('Products onSnapshot notification:', error);
        }
      });
    } catch (e) {
      if (!isOfflineError(e)) {
        console.warn('Could not attach products snapshot listener:', e);
      }
      return () => {};
    }
  },

  async saveCategory(category: Category): Promise<void> {
    try {
      const docRef = doc(db, 'categories', category.id);
      await setDoc(docRef, sanitizeForFirestore(category), { merge: true });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving category to Firestore:', err);
      }
    }
  },

  async deleteCategory(id: string): Promise<void> {
    try {
      const docRef = doc(db, 'categories', id);
      await deleteDoc(docRef);
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error deleting category from Firestore:', err);
      }
    }
  },

  subscribeToCategories(callback: (categories: Category[]) => void): Unsubscribe {
    try {
      const q = collection(db, 'categories');
      return onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: Category[] = [];
          snapshot.forEach((d) => {
            list.push(d.data() as Category);
          });
          callback(list);
        }
      }, (error) => {
        if (!isOfflineError(error)) {
          console.warn('Categories onSnapshot notification:', error);
        }
      });
    } catch (e) {
      if (!isOfflineError(e)) {
        console.warn('Could not attach categories snapshot listener:', e);
      }
      return () => {};
    }
  },

  async getBrands(): Promise<Brand[]> {
    try {
      const querySnapshot = await getDocs(collection(db, 'brands'));
      if (!querySnapshot.empty) {
        const list: Brand[] = [];
        querySnapshot.forEach((d) => {
          list.push(d.data() as Brand);
        });
        return list;
      }
      return [];
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching brands from Firestore:', err);
      }
      return [];
    }
  },

  async saveBrand(brand: Brand): Promise<void> {
    try {
      const docRef = doc(db, 'brands', brand.id);
      await setDoc(docRef, sanitizeForFirestore({
        ...brand,
        updatedAt: new Date().toISOString(),
      }), { merge: true });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving brand to Firestore:', err);
      }
      throw err;
    }
  },

  async deleteBrand(id: string): Promise<void> {
    try {
      const docRef = doc(db, 'brands', id);
      await deleteDoc(docRef);
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error deleting brand from Firestore:', err);
      }
      throw err;
    }
  },

  subscribeToBrands(callback: (brands: Brand[]) => void): Unsubscribe {
    try {
      const q = collection(db, 'brands');
      return onSnapshot(q, (snapshot) => {
        const list: Brand[] = [];
        snapshot.forEach((d) => {
          list.push(d.data() as Brand);
        });
        callback(list);
      }, (error) => {
        if (!isOfflineError(error)) {
          console.warn('Brands onSnapshot notification:', error);
        }
      });
    } catch (e) {
      if (!isOfflineError(e)) {
        console.warn('Could not attach brands snapshot listener:', e);
      }
      return () => {};
    }
  }
};

export async function uploadBrandImage(file: File, type: 'logo' | 'cover' = 'logo'): Promise<string> {
  try {
    const maxWidth = type === 'cover' ? 1400 : 600;
    const compressedBlob = await compressImage(file, maxWidth, 0.85);
    const filename = `brands/${type}_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.jpg`;
    const storageRef = ref(storage, filename);
    
    const snapshot = await uploadBytes(storageRef, compressedBlob, {
      contentType: 'image/jpeg',
    });
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (storageError) {
    console.warn(`Firebase Storage brand ${type} upload note (falling back to Data URL):`, storageError);
    const compressedBlob = await compressImage(file, type === 'cover' ? 900 : 400, 0.80);
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(compressedBlob);
    });
  }
}

let cachedSupportsWebP: boolean | null = null;
function supportsWebPEncode(): boolean {
  if (cachedSupportsWebP !== null) return cachedSupportsWebP;
  try {
    const c = document.createElement('canvas');
    c.width = 2;
    c.height = 2;
    cachedSupportsWebP = c.toDataURL('image/webp').startsWith('data:image/webp');
  } catch {
    cachedSupportsWebP = false;
  }
  return cachedSupportsWebP;
}

export async function compressImage(file: File, maxWidth = 1080, quality = 0.78): Promise<Blob> {
  if (file.size < 90 * 1024 && (file.type === 'image/webp' || file.type === 'image/jpeg')) {
    return file;
  }

  return new Promise((resolve) => {
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const canvas = document.createElement('canvas');
      let width = img.naturalWidth || img.width;
      let height = img.naturalHeight || img.height;

      if (width > maxWidth || height > maxWidth) {
        if (width >= height) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        } else {
          width = Math.round((width * maxWidth) / height);
          height = maxWidth;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d', { alpha: false });
      if (!ctx) {
        resolve(file);
        return;
      }
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'medium';
      ctx.drawImage(img, 0, 0, width, height);

      const targetMime = supportsWebPEncode() ? 'image/webp' : 'image/jpeg';
      canvas.toBlob(
        (blob) => {
          if (blob && blob.size > 0) {
            resolve(blob);
          } else {
            resolve(file);
          }
        },
        targetMime,
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(file);
    };

    img.src = objectUrl;
  });
}

export async function uploadProductImage(file: File): Promise<string> {
  const compressedBlob = await compressImage(file, 1080, 0.78);
  const isWebP = compressedBlob.type === 'image/webp';
  const ext = isWebP ? 'webp' : 'jpg';
  const filename = `products/${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
  const storageRef = ref(storage, filename);

  try {
    const uploadTask = uploadBytes(storageRef, compressedBlob, {
      contentType: isWebP ? 'image/webp' : 'image/jpeg',
    });

    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Storage upload timeout')), 6000);
    });

    const snapshot = await Promise.race([uploadTask, timeoutPromise]);
    return await getDownloadURL(snapshot.ref);
  } catch (storageError) {
    console.warn('Firebase Storage direct upload fast fallback to optimized Data URL:', storageError);
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(compressedBlob);
    });
  }
}

export const firestoreUserService = {
  async getCart(userId: string): Promise<CartItem[]> {
    try {
      const docRef = doc(db, 'carts', userId);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        return data.items || [];
      }
      return [];
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching cart from Firestore:', err);
      }
      return [];
    }
  },

  async saveCart(userId: string, items: CartItem[]): Promise<void> {
    try {
      const docRef = doc(db, 'carts', userId);
      await setDoc(docRef, sanitizeForFirestore({
        userId,
        items,
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving cart to Firestore:', err);
      }
    }
  },

  async getFavorites(userId: string): Promise<string[]> {
    try {
      const docRef = doc(db, 'favorites', userId);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        return data.productIds || [];
      }
      return [];
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching favorites from Firestore:', err);
      }
      return [];
    }
  },

  async saveFavorites(userId: string, productIds: string[]): Promise<void> {
    try {
      const docRef = doc(db, 'favorites', userId);
      await setDoc(docRef, sanitizeForFirestore({
        userId,
        productIds,
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving favorites to Firestore:', err);
      }
    }
  },

  async getAddresses(userId: string): Promise<Address[]> {
    try {
      const querySnapshot = await getDocs(collection(db, 'users', userId, 'addresses'));
      const list: Address[] = [];
      querySnapshot.forEach((d) => {
        list.push(d.data() as Address);
      });
      return list;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching addresses from Firestore:', err);
      }
      return [];
    }
  },

  async saveAddress(userId: string, address: Address): Promise<void> {
    try {
      const docRef = doc(db, 'users', userId, 'addresses', address.id);
      await setDoc(docRef, sanitizeForFirestore(address));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving address to Firestore:', err);
      }
    }
  },

  async deleteAddress(userId: string, addressId: string): Promise<void> {
    try {
      const docRef = doc(db, 'users', userId, 'addresses', addressId);
      await deleteDoc(docRef);
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error deleting address from Firestore:', err);
      }
    }
  }
};

export const firestoreOrderService = {
  async createOrder(order: Order): Promise<void> {
    try {
      await runTransaction(db, async (transaction) => {
        for (const item of order.items) {
          if (item.product?.id) {
            const productRef = doc(db, 'products', item.product.id);
            try {
              const productDoc = await transaction.get(productRef);
              if (productDoc.exists()) {
                const currentStock = productDoc.data().stock ?? 10;
                const newStock = Math.max(0, currentStock - item.quantity);
                transaction.update(productRef, { stock: newStock });
              }
            } catch (pErr) {
            }
          }
        }

        const orderRef = doc(db, 'orders', order.id);
        const cleanOrderData = sanitizeForFirestore({
          ...order,
          createdAt: order.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        transaction.set(orderRef, cleanOrderData);
      });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Transaction order creation notice (falling back to direct setDoc):', err);
      }
      try {
        const docRef = doc(db, 'orders', order.id);
        const cleanOrderData = sanitizeForFirestore({
          ...order,
          createdAt: order.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        await setDoc(docRef, cleanOrderData);
      } catch (fallbackErr) {
        if (!isOfflineError(fallbackErr)) {
          handleFirestoreError(fallbackErr, OperationType.CREATE, `orders/${order.id}`);
          throw fallbackErr;
        }
      }
    }
  },

  async getUserOrders(userId: string): Promise<Order[]> {
    try {
      const q = query(
        collection(db, 'orders'),
        where('userId', '==', userId),
        limit(50)
      );
      const querySnapshot = await withFirestoreTimeout(getDocs(q), 3000, null);
      if (!querySnapshot) return [];
      const orders: Order[] = [];
      querySnapshot.forEach((d) => {
        orders.push(d.data() as Order);
      });
      return orders;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching orders from Firestore:', err);
      }
      return [];
    }
  },

  async updateOrderStatus(orderId: string, status: Order['status']): Promise<void> {
    try {
      const docRef = doc(db, 'orders', orderId);
      await updateDoc(docRef, sanitizeForFirestore({
        status,
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error updating order status in Firestore:', err);
      }
      throw err;
    }
  },

  async cancelCustomerOrder(orderId: string, userId: string): Promise<void> {
    const docRef = doc(db, 'orders', orderId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      throw new Error('الطلب غير موجود في النظام.');
    }
    const orderData = snap.data() as Order;
    const isAppAdmin = auth.currentUser?.email?.toLowerCase() === OWNER_EMAIL && auth.currentUser?.emailVerified === true;
    if (orderData.userId !== userId && !isAppAdmin) {
      throw new Error('غير مصرح لك بإلغاء هذا الطلب.');
    }
    if (orderData.status !== 'received') {
      throw new Error('لا يمكن إلغاء الطلب لأنه بدأ بالفعل في مرحلة التجهيز أو خرج للتوصيل أو تم تسليمه.');
    }
    await updateDoc(docRef, sanitizeForFirestore({
      status: 'cancelled',
      updatedAt: new Date().toISOString(),
    }));
  }
};

export const firestoreConfigService = {
  async getCurrencyRates(): Promise<ExchangeRates> {
    try {
      const docRef = doc(db, 'currencySettings', 'config');
      const snap = await withFirestoreTimeout(getDoc(docRef), 2500, null);
      if (snap && snap.exists()) {
        const data = snap.data();
        if (data.rates) {
          return data.rates as ExchangeRates;
        }
      }

      try {
        await setDoc(docRef, {
          rates: DEFAULT_EXCHANGE_RATES,
          lastUpdated: new Date().toISOString(),
        });
      } catch (e) {
      }
      return DEFAULT_EXCHANGE_RATES;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error reading currency settings from Firestore:', err);
      }
      return DEFAULT_EXCHANGE_RATES;
    }
  },

  async saveCurrencyRates(rates: ExchangeRates): Promise<void> {
    try {
      const docRef = doc(db, 'currencySettings', 'config');
      await setDoc(docRef, {
        rates,
        lastUpdated: new Date().toISOString(),
      });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving currency settings to Firestore:', err);
      }
    }
  }
};

export const firestoreSettingsService = {
  async getSettings(): Promise<Partial<AppSettings> | null> {
    try {
      const docRef = doc(db, 'appSettings', 'general');
      const snap = await withFirestoreTimeout(getDoc(docRef), 2500, null);
      if (snap && snap.exists()) {
        return snap.data() as Partial<AppSettings>;
      }
      return null;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error reading app settings from Firestore:', err);
      }
      return null;
    }
  },

  async saveSettings(settings: Partial<AppSettings>): Promise<void> {
    try {
      const docRef = doc(db, 'appSettings', 'general');
      await setDoc(docRef, sanitizeForFirestore({
        ...settings,
        updatedAt: new Date().toISOString(),
      }), { merge: true });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving app settings to Firestore:', err);
      }
    }
  },

  subscribeToSettings(callback: (settings: Partial<AppSettings>) => void): Unsubscribe {
    try {
      const docRef = doc(db, 'appSettings', 'general');
      return onSnapshot(docRef, (snapshot) => {
        if (snapshot.exists()) {
          callback(snapshot.data() as Partial<AppSettings>);
        }
      }, (error) => {
        if (!isOfflineError(error)) {
          console.warn('Settings onSnapshot notice:', error);
        }
      });
    } catch (e) {
      return () => {};
    }
  }
};

export const firestoreFooterService = {
  async getFooterConfig(): Promise<FooterConfig | null> {
    try {
      const docRef = doc(db, 'footer_config', 'main');
      const snap = await withFirestoreTimeout(getDoc(docRef), 2500, null);
      if (snap && snap.exists()) {
        const data = snap.data();
        return { ...DEFAULT_FOOTER_CONFIG, ...data } as FooterConfig;
      }
      return null;
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error reading footer config from Firestore:', err);
      }
      return null;
    }
  },

  async saveFooterConfig(footerConfig: Partial<FooterConfig>): Promise<void> {
    try {
      const docRef = doc(db, 'footer_config', 'main');
      await setDoc(docRef, sanitizeForFirestore({
        ...footerConfig,
        updatedAt: new Date().toISOString(),
      }), { merge: true });
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving footer config to Firestore:', err);
      }
      throw err;
    }
  },

  subscribeToFooterConfig(callback: (config: FooterConfig) => void): Unsubscribe {
    try {
      const docRef = doc(db, 'footer_config', 'main');
      return onSnapshot(docRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          callback({ ...DEFAULT_FOOTER_CONFIG, ...data } as FooterConfig);
        }
      }, (error) => {
        if (!isOfflineError(error)) {
          console.warn('FooterConfig onSnapshot notice:', error);
        }
      });
    } catch (e) {
      return () => {};
    }
  },

  async uploadFooterLogo(file: File): Promise<string> {
    try {
      const compressedBlob = await compressImage(file, 600, 0.88);
      const filename = `footer/logos/logo_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.png`;
      const storageRef = ref(storage, filename);
      const snapshot = await uploadBytes(storageRef, compressedBlob, {
        contentType: 'image/png',
      });
      return await getDownloadURL(snapshot.ref);
    } catch (storageError) {
      console.warn('Firebase Storage footer logo upload note (falling back to Data URL):', storageError);
      const compressedBlob = await compressImage(file, 400, 0.85);
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(compressedBlob);
      });
    }
  }
};

export const firestoreReviewService = {
  async addReview(reviewData: {
    productId: string;
    productName?: string;
    productImage?: string;
    userId: string;
    userName: string;
    userAvatar?: string;
    rating: number;
    comment: string;
    verifiedPurchase: boolean;
    images?: string[];
  }): Promise<ReviewItem> {
    const reviewId = `rev_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const fullReview: ReviewItem = {
      id: reviewId,
      productId: reviewData.productId,
      productName: reviewData.productName || '',
      productImage: reviewData.productImage || '',
      userId: reviewData.userId,
      userName: reviewData.userName || 'مشتري موثق',
      userAvatar: reviewData.userAvatar || '',
      rating: Math.max(1, Math.min(5, Math.round(reviewData.rating))),
      comment: reviewData.comment.trim(),
      date: new Date().toLocaleDateString('ar-YE', { year: 'numeric', month: 'short', day: 'numeric' }),
      verifiedPurchase: reviewData.verifiedPurchase,
      images: reviewData.images || [],
      isHidden: false,
      isApproved: true,
    };

    try {
      const docRef = doc(db, 'reviews', reviewId);
      await setDoc(docRef, sanitizeForFirestore({
        ...fullReview,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error saving review to Firestore:', err);
      }
    }

    return fullReview;
  },

  async getProductReviews(productId: string): Promise<ReviewItem[]> {
    try {
      const q = query(
        collection(db, 'reviews'),
        where('productId', '==', productId),
        limit(50)
      );
      const querySnapshot = await withFirestoreTimeout(getDocs(q), 2500, null);
      if (querySnapshot && !querySnapshot.empty) {
        const list: ReviewItem[] = [];
        querySnapshot.forEach((d) => {
          const item = d.data() as ReviewItem;
          if (!item.isHidden) {
            list.push(item);
          }
        });
        return list;
      }
      return [];
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error fetching product reviews from Firestore:', err);
      }
      return [];
    }
  },

  subscribeToProductReviews(productId: string, callback: (reviews: ReviewItem[]) => void): Unsubscribe {
    try {
      const q = query(collection(db, 'reviews'), where('productId', '==', productId), limit(50));
      return onSnapshot(q, (snapshot) => {
        const list: ReviewItem[] = [];
        snapshot.forEach((d) => {
          const item = d.data() as ReviewItem;
          if (!item.isHidden) {
            list.push(item);
          }
        });
        callback(list);
      }, (error) => {
        if (!isOfflineError(error)) {
          console.warn('Product reviews onSnapshot notice:', error);
        }
      });
    } catch (e) {
      return () => {};
    }
  },

  async deleteReview(reviewId: string): Promise<void> {
    try {
      const docRef = doc(db, 'reviews', reviewId);
      await deleteDoc(docRef);
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error deleting review from Firestore:', err);
      }
    }
  },

  async toggleHideReview(reviewId: string, isHidden: boolean): Promise<void> {
    try {
      const docRef = doc(db, 'reviews', reviewId);
      await updateDoc(docRef, sanitizeForFirestore({
        isHidden,
        updatedAt: new Date().toISOString(),
      }));
    } catch (err) {
      if (!isOfflineError(err)) {
        console.warn('Error updating review visibility in Firestore:', err);
      }
    }
  }
};

export const firebaseStorageService = {
  async uploadFile(file: File | Blob, path: string): Promise<string> {
    try {
      const storageRef = ref(storage, path);
      const snapshot = await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(snapshot.ref);
      return downloadURL;
    } catch (err) {
      console.error('Error uploading file to Firebase Storage:', err);
      throw err;
    }
  }
};

export const firebaseNotificationService = {
  async requestNotificationPermission(): Promise<string | null> {
    try {
      if (typeof window !== 'undefined' && 'Notification' in window) {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          console.log('Notification permission granted.');
          return 'granted';
        }
      }
      return null;
    } catch (err) {
      console.error('Error requesting notification permission:', err);
      return null;
    }
  }
};
