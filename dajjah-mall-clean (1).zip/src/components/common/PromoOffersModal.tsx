import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Sparkles, Tag, Gift, ArrowLeft, Check, Copy } from 'lucide-react';
import { PopupOffer } from '../../types';
import { DEFAULT_POPUP_OFFER } from '../../data/mockData';

interface PromoOffersModalProps {
  offer?: PopupOffer | null;
  onOpenCategory?: (categoryId: string) => void;
  onOpenDeals?: () => void;
  onApplyCoupon?: (code: string) => void;
}

export const PromoOffersModal: React.FC<PromoOffersModalProps> = ({
  offer: customOffer,
  onOpenCategory,
  onOpenDeals,
  onApplyCoupon,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const offer = customOffer || DEFAULT_POPUP_OFFER;

  useEffect(() => {
    if (!offer || offer.isActive === false) return;

    const storageKey = `dajjah_popup_seen_${offer.id}`;
    const seenTimestamp = localStorage.getItem(storageKey);

    if (offer.showFrequency === 'once_per_session') {
      const sessionSeen = sessionStorage.getItem(storageKey);
      if (sessionSeen) return;
    } else if (offer.showFrequency === 'once_per_day' && seenTimestamp) {
      const oneDay = 24 * 60 * 60 * 1000;
      if (Date.now() - parseInt(seenTimestamp, 10) < oneDay) return;
    }

    const delay = (offer.delaySeconds || 2) * 1000;
    const timer = setTimeout(() => {
      setIsOpen(true);
      if (offer.showFrequency === 'once_per_session') {
        sessionStorage.setItem(storageKey, 'true');
      } else {
        localStorage.setItem(storageKey, Date.now().toString());
      }
    }, delay);

    return () => clearTimeout(timer);
  }, [offer]);

  if (!isOpen || !offer || offer.isActive === false) return null;

  const handleCopyCoupon = () => {
    if (offer.couponCode) {
      navigator.clipboard.writeText(offer.couponCode);
      setCopied(true);
      if (onApplyCoupon) onApplyCoupon(offer.couponCode);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleCtaClick = () => {
    setIsOpen(false);
    if (offer.couponCode && onApplyCoupon) {
      onApplyCoupon(offer.couponCode);
    }
    if (offer.linkType === 'category' && onOpenCategory) {
      onOpenCategory(offer.linkTarget || 'women');
    } else if (onOpenDeals) {
      onOpenDeals();
    }
  };

  return (
    <div 
      id="promo-popup-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
    >
        <motion.div
          initial={{ opacity: 0, scale: 0.85, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: 20 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="relative w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl text-right select-none"
          id="promo-popup-card"
        >
          <button
            type="button"
            id="btn-close-promo-popup"
            onClick={() => setIsOpen(false)}
            className="absolute top-3 left-3 z-30 p-1.5 rounded-full bg-neutral-900/80 border border-neutral-700/70 text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer shadow-md"
            aria-label="إغلاق الإعلان"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="relative w-full h-36 sm:h-40 overflow-hidden">
            <img
              src={offer.imageUrl || 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=600&auto=format&fit=crop'}
              alt={offer.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
            
            {offer.discountPercentage ? (
              <div className="absolute bottom-2 right-3 px-3 py-1 rounded-full bg-amber-400 text-neutral-950 font-black text-xs shadow-lg flex items-center gap-1.5 animate-bounce">
                <Tag className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>خصم {offer.discountPercentage}%</span>
              </div>
            ) : (
              <div className="absolute bottom-2 right-3 px-3 py-1 rounded-full bg-purple-600 text-white font-black text-xs shadow-lg flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5" />
                <span>عرض خاص</span>
              </div>
            )}
          </div>

          <div className="p-4 sm:p-5 space-y-3.5">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>ضَجّة مول — عرض محدود</span>
              </span>
              <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                {offer.title}
              </h3>
              {offer.subtitle && (
                <p className="text-xs font-bold text-neutral-300">
                  {offer.subtitle}
                </p>
              )}
              <p className="text-xs text-neutral-400 leading-relaxed pt-0.5">
                {offer.description}
              </p>
            </div>

            {offer.couponCode && (
              <div className="p-2.5 rounded-2xl bg-neutral-900/90 border border-dashed border-amber-500/50 flex items-center justify-between gap-2">
                <button
                  type="button"
                  id="btn-copy-popup-coupon"
                  onClick={handleCopyCoupon}
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>تم النسخ!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ الكوبون</span>
                    </>
                  )}
                </button>
                <div className="text-left font-mono font-black text-amber-400 text-sm tracking-wider">
                  {offer.couponCode}
                </div>
              </div>
            )}

            <button
              type="button"
              id="btn-popup-cta-shop"
              onClick={handleCtaClick}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 hover:brightness-110 text-neutral-950 text-xs sm:text-sm font-black shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>{offer.ctaText || 'تسوّق واستفد من العرض الآن'}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>
  );
};
