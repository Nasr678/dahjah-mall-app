import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { 
  Store, 
  Phone, 
  Clock, 
  Navigation, 
  Star, 
  X, 
  Layers
} from 'lucide-react';
import { 
  DAJJAH_BRANCHES, 
  DajjahBranchLocation, 
  CARTO_DARK_TILE_LAYER,
  OSM_TILE_LAYER,
  createCustomMarkerIcon 
} from '../../services/leafletMapService';

interface LeafletStoreLocatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LeafletStoreLocatorModal: React.FC<LeafletStoreLocatorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [activeBranch, setActiveBranch] = useState<DajjahBranchLocation>(DAJJAH_BRANCHES[0]);
  const [activeTile, setActiveTile] = useState<'voyager' | 'osm'>('voyager');

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const markersGroupRef = useRef<L.LayerGroup | null>(null);

  const filteredBranches = selectedCity === 'all'
    ? DAJJAH_BRANCHES
    : DAJJAH_BRANCHES.filter((b) => b.city.includes(selectedCity) || selectedCity.includes(b.city));

  const tileConfig = activeTile === 'voyager' ? CARTO_DARK_TILE_LAYER : OSM_TILE_LAYER;

  useEffect(() => {
    if (!isOpen || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [activeBranch.lat, activeBranch.lng],
        zoom: 14,
        zoomControl: false,
        attributionControl: false,
      });

      const tileLayer = L.tileLayer(tileConfig.url, {
        maxZoom: tileConfig.maxZoom,
      }).addTo(map);
      tileLayerRef.current = tileLayer;

      const markersGroup = L.layerGroup().addTo(map);
      markersGroupRef.current = markersGroup;

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        tileLayerRef.current = null;
        markersGroupRef.current = null;
      }
    };
  }, [isOpen]);

  useEffect(() => {
    if (!mapInstanceRef.current) return;
    if (tileLayerRef.current) {
      mapInstanceRef.current.removeLayer(tileLayerRef.current);
    }
    const newTile = L.tileLayer(tileConfig.url, { maxZoom: tileConfig.maxZoom }).addTo(mapInstanceRef.current);
    tileLayerRef.current = newTile;
  }, [activeTile, tileConfig.url, tileConfig.maxZoom]);

  useEffect(() => {
    if (!mapInstanceRef.current || !markersGroupRef.current) return;

    markersGroupRef.current.clearLayers();

    filteredBranches.forEach((b) => {
      const isSelected = activeBranch.id === b.id;
      const branchIcon = createCustomMarkerIcon(
        isSelected ? 'hub' : 'store',
        isSelected ? b.district : undefined
      );

      const marker = L.marker([b.lat, b.lng], { icon: branchIcon });
      marker.on('click', () => {
        setActiveBranch(b);
      });
      marker.addTo(markersGroupRef.current!);
    });

    mapInstanceRef.current.setView([activeBranch.lat, activeBranch.lng], 15, { animate: true });
  }, [filteredBranches, activeBranch]);

  if (!isOpen) return null;

  const openDirections = (branch: DajjahBranchLocation) => {
    const url = `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=%3B${branch.lat}%2C${branch.lng}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-[9995] flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl text-white my-auto overflow-hidden flex flex-col max-h-[92vh]">
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white">فروع ومراكز ضَجّة مول</h3>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  خريطة تفاعلية
                </span>
              </div>
              <p className="text-xs text-neutral-400">مواقع الفروع الرسمية ومراكز الاستلام الفوري في المحافظات اليمنية</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-4 py-2.5 bg-neutral-950 border-b border-neutral-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', name: 'جميع الفروع' },
            { id: 'صنعاء', name: 'صنعاء' },
            { id: 'عدن', name: 'عدن' },
            { id: 'تعز', name: 'تعز' },
            { id: 'حضرموت', name: 'حضرموت' },
            { id: 'إب', name: 'إب' },
            { id: 'الحديدة', name: 'الحديدة' },
          ].map((city) => (
            <button
              key={city.id}
              type="button"
              onClick={() => setSelectedCity(city.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCity === city.id
                  ? 'bg-amber-400 text-neutral-950 shadow-md font-black ring-1 ring-amber-400'
                  : 'bg-neutral-900 text-neutral-400 hover:bg-neutral-800 hover:text-white border border-neutral-800'
              }`}
            >
              {city.name}
            </button>
          ))}
        </div>

        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden min-h-[380px] sm:min-h-[460px]">
          <div className="md:col-span-5 p-3.5 sm:p-4 overflow-y-auto space-y-2.5 max-h-[260px] md:max-h-[500px] border-b md:border-b-0 md:border-l border-neutral-800">
            {filteredBranches.map((branch) => {
              const isSelected = activeBranch.id === branch.id;
              return (
                <div
                  key={branch.id}
                  onClick={() => setActiveBranch(branch)}
                  className={`p-3 sm:p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-400 ring-1 ring-amber-400/40 shadow-lg shadow-amber-500/5'
                      : 'bg-neutral-950/60 hover:bg-neutral-950 border-neutral-800/80 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-xl ${
                        isSelected ? 'bg-amber-400 text-neutral-950' : 'bg-neutral-800 text-neutral-400'
                      }`}>
                        <Store className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs sm:text-sm text-white">{branch.nameAr}</h4>
                        <span className="text-[11px] text-amber-400/90 font-medium">{branch.city} • {branch.district}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>{branch.rating}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-neutral-400 line-clamp-1 mb-2">
                    {branch.address}
                  </p>

                  <div className="flex items-center justify-between text-[11px] pt-2 border-t border-neutral-800/60">
                    <span className="text-neutral-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-neutral-500" />
                      <span>{branch.workingHours}</span>
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        openDirections(branch);
                      }}
                      className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      <Navigation className="w-3 h-3" />
                      <span>الاتجاهات</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="md:col-span-7 relative w-full h-[280px] md:h-full bg-neutral-950">
            <div
              ref={mapContainerRef}
              className="w-full h-full min-h-[280px]"
              style={{ background: '#121212' }}
            />

            <div className="absolute bottom-3 inset-x-3 z-[1000] pointer-events-auto">
              <div className="p-3 rounded-2xl bg-neutral-950/90 backdrop-blur-md border border-neutral-800 text-white shadow-2xl flex items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="font-bold text-xs text-white">{activeBranch.nameAr}</div>
                  <div className="text-[11px] text-neutral-400 flex items-center gap-2">
                    <span>{activeBranch.phone}</span>
                    <span>•</span>
                    <span className="text-amber-400 font-bold">{activeBranch.workingHours}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <a
                    href={`tel:${activeBranch.phone}`}
                    className="p-2 rounded-xl bg-neutral-850 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 transition-colors"
                    title="اتصال بالفرع"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                  <button
                    type="button"
                    onClick={() => openDirections(activeBranch)}
                    className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>خريطة</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="absolute top-3 left-3 z-[1000]">
              <button
                type="button"
                onClick={() => setActiveTile((prev) => (prev === 'voyager' ? 'osm' : 'voyager'))}
                className="px-2.5 py-1.5 rounded-xl bg-neutral-900/90 hover:bg-neutral-850 text-neutral-300 hover:text-white border border-neutral-700/80 text-[11px] font-bold flex items-center gap-1.5 backdrop-blur-md shadow-lg transition-colors cursor-pointer"
              >
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>{activeTile === 'voyager' ? 'خريطة داكنة' : 'خريطة الشارع'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
