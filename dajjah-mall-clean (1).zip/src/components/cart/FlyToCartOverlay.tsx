import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'motion/react';
import { CachedImage } from '../common/CachedImage';

export interface FlyEventDetail {
  id?: string;
  imageUrl: string;
  startX?: number;
  startY?: number;
}

interface FlyingParticle {
  id: string;
  imageUrl: string;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
}

export const safeHaptic = (pattern: number | number[] = 20) => {
  try {
    if (typeof window !== 'undefined' && 'navigator' in window && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch {
  }
};

export const triggerFlyToCart = (
  imageUrl: string,
  source?: { x: number; y: number } | HTMLElement | null
) => {
  safeHaptic(15);

  requestAnimationFrame(() => {
    let startX: number | undefined;
    let startY: number | undefined;

    if (source) {
      try {
        if ('getBoundingClientRect' in source && typeof source.getBoundingClientRect === 'function') {
          const rect = source.getBoundingClientRect();
          startX = rect.left + rect.width / 2;
          startY = rect.top + rect.height / 2;
        } else if ('x' in source && 'y' in source) {
          startX = source.x;
          startY = source.y;
        }
      } catch {
      }
    }

    window.dispatchEvent(
      new CustomEvent<FlyEventDetail>('dahjah:fly-to-cart', {
        detail: {
          id: `fly-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          imageUrl,
          startX,
          startY,
        },
      })
    );
  });
};

export const FlyToCartOverlay: React.FC = () => {
  const [particles, setParticles] = useState<FlyingParticle[]>([]);
  const targetPosCache = useRef<{ x: number; y: number } | null>(null);

  const handleFlyEvent = useCallback((event: Event) => {
    const customEvent = event as CustomEvent<FlyEventDetail>;
    const detail = customEvent.detail;
    if (!detail || !detail.imageUrl) return;

    let targetX = window.innerWidth - 56;
    let targetY = 28;

    try {
      const cartBtn = document.getElementById('btn-header-cart');
      if (cartBtn) {
        const rect = cartBtn.getBoundingClientRect();
        targetX = rect.left + rect.width / 2;
        targetY = rect.top + rect.height / 2;
        targetPosCache.current = { x: targetX, y: targetY };
      } else if (targetPosCache.current) {
        targetX = targetPosCache.current.x;
        targetY = targetPosCache.current.y;
      }
    } catch {
      if (targetPosCache.current) {
        targetX = targetPosCache.current.x;
        targetY = targetPosCache.current.y;
      }
    }

    const startX = detail.startX !== undefined ? detail.startX : window.innerWidth / 2;
    const startY = detail.startY !== undefined ? detail.startY : window.innerHeight * 0.72;

    const newParticle: FlyingParticle = {
      id: detail.id || `fly-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      imageUrl: detail.imageUrl,
      startX,
      startY,
      targetX,
      targetY,
    };

    setParticles((prev) => [...prev, newParticle]);
  }, []);

  useEffect(() => {
    window.addEventListener('dahjah:fly-to-cart', handleFlyEvent, { passive: true });
    return () => window.removeEventListener('dahjah:fly-to-cart', handleFlyEvent);
  }, [handleFlyEvent]);

  const onParticleComplete = useCallback((id: string) => {
    setParticles((prev) => prev.filter((p) => p.id !== id));

    requestAnimationFrame(() => {
      const cartBtn = document.getElementById('btn-header-cart');
      if (cartBtn) {
        cartBtn.classList.remove('animate-cart-bounce');
        void cartBtn.offsetWidth;
        cartBtn.classList.add('animate-cart-bounce');
        setTimeout(() => cartBtn.classList.remove('animate-cart-bounce'), 500);
      }

      const bottomCart = document.getElementById('bottom-nav-cart');
      if (bottomCart) {
        bottomCart.classList.remove('animate-cart-bounce');
        void bottomCart.offsetWidth;
        bottomCart.classList.add('animate-cart-bounce');
        setTimeout(() => bottomCart.classList.remove('animate-cart-bounce'), 500);
      }

      safeHaptic([20, 25]);
    });
  }, []);

  if (particles.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-[999999] overflow-hidden">
      {particles.map((p) => {
        const midX = (p.startX + p.targetX) / 2 + (p.startX < p.targetX ? -28 : 28);
        const arcApexY = Math.min(p.targetY, p.startY) - Math.max(55, Math.abs(p.startY - p.targetY) * 0.2);

        return (
          <motion.div
            key={p.id}
            initial={{
              x: p.startX - 26,
              y: p.startY - 26,
              scale: 1,
              rotate: 0,
              opacity: 1,
            }}
            animate={{
              x: [p.startX - 26, midX - 18, p.targetX - 8],
              y: [p.startY - 26, arcApexY, p.targetY - 8],
              scale: [1, 0.72, 0.16],
              rotate: [0, -14, 18],
              opacity: [1, 1, 0.3],
            }}
            transition={{
              duration: 0.5,
              times: [0, 0.44, 1],
              ease: ['easeOut', 'easeInOut'],
            }}
            onAnimationComplete={() => onParticleComplete(p.id)}
            className="absolute top-0 left-0 w-14 h-14 rounded-2xl overflow-hidden border-2 border-amber-400 bg-neutral-900 shadow-2xl shadow-amber-500/50 ring-2 ring-amber-400/60 gpu-layer"
            style={{
              willChange: 'transform, opacity',
              transformOrigin: 'center center',
            }}
          >
            <CachedImage
              src={p.imageUrl}
              alt="Flying Product"
              preset="thumb"
              containerClassName="w-full h-full"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/30 to-transparent pointer-events-none" />
          </motion.div>
        );
      })}
    </div>
  );
};
