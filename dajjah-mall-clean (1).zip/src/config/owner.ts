export const OWNER_EMAIL = 'nsralnaty93@gmail.com';
